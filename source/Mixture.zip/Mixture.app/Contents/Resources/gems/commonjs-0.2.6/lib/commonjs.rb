require "commonjs/version"

module CommonJS
  autoload :Environment,  'commonjs/environment'
  autoload :Module,       'commonjs/module'
end
