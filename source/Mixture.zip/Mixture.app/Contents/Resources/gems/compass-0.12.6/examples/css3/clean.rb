require 'fileutils'
FileUtils.rm_rf "#{File.dirname(__FILE__)}/extensions/compass-colors"
