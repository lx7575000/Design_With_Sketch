# Require any additional compass plugins here.
project_type = :stand_alone
css_dir = "stylesheets"
sass_dir = "src"
images_dir = "images"
relative_assets = true
